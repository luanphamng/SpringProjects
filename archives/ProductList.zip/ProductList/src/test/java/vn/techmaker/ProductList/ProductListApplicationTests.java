package vn.techmaker.ProductList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductListApplicationTests {

	@Test
	void contextLoads() {
	}

}
